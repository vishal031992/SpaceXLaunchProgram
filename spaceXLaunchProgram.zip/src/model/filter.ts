export class ProgramFilter {
    launch_success: string;
    land_success:string;
    launch_year: string
}